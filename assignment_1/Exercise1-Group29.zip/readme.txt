#Ray-plane intersection & #Ray-cylinder intersection + normal derivations (theory exercise)
Derivations can be found in TheoryExercise.pdf
#Ray-cylinder intersection implementation & #Cylinder normal implementation
Implementation can be found in corresponding .cpp files

Reference:
We have refered to an online lecture note about the expressions of infinite cylinder and thus derived our own desired solution to the problem (in this case, a finite cylinder without caps), the reference material is in the zip folder as well.